# Proguard Rules for EchoGram

# Keep all classes in our package
-keep class com.echogram.** { *; }

# Keep data classes
-keepclassmembers class com.echogram.** {
    *** get*();
    void set*(***);
}

# Keep Compose classes
-keep class androidx.compose.** { *; }
-keepclassmembers class androidx.compose.** { *; }

# Keep Material3 classes
-keep class androidx.compose.material3.** { *; }

# Keep Navigation classes
-keep class androidx.navigation.** { *; }

# Keep Room database classes
-keep class androidx.room.** { *; }
-keepclassmembers class androidx.room.** { *; }

# Keep Kotlin coroutines
-keep class kotlinx.coroutines.** { *; }
-keepclassmembers class kotlinx.coroutines.** { *; }

# Keep Hilt classes
-keep class com.google.dagger.hilt.** { *; }
-keepclassmembers class com.google.dagger.hilt.** { *; }

# Remove logging in release builds
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# Optimization settings
-optimizationpasses 5
-dontusemixedcaseclassnames
-verbose

# Preserve line numbers for debugging
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
