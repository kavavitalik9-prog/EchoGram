package com.echogram.data.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class GhostModeManager(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "ghost_mode_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val _ghostModeEnabled = MutableStateFlow(getGhostModeEnabled())
    val ghostModeEnabled: StateFlow<Boolean> = _ghostModeEnabled

    private val _hideOnlineStatus = MutableStateFlow(getHideOnlineStatus())
    val hideOnlineStatus: StateFlow<Boolean> = _hideOnlineStatus

    private val _hideTypingIndicator = MutableStateFlow(getHideTypingIndicator())
    val hideTypingIndicator: StateFlow<Boolean> = _hideTypingIndicator

    private val _hideReadReceipts = MutableStateFlow(getHideReadReceipts())
    val hideReadReceipts: StateFlow<Boolean> = _hideReadReceipts

    // Getters
    private fun getGhostModeEnabled(): Boolean {
        return sharedPreferences.getBoolean("ghost_mode_enabled", false)
    }

    private fun getHideOnlineStatus(): Boolean {
        return sharedPreferences.getBoolean("hide_online_status", false)
    }

    private fun getHideTypingIndicator(): Boolean {
        return sharedPreferences.getBoolean("hide_typing_indicator", false)
    }

    private fun getHideReadReceipts(): Boolean {
        return sharedPreferences.getBoolean("hide_read_receipts", false)
    }

    // Setters
    fun setGhostModeEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("ghost_mode_enabled", enabled).apply()
        _ghostModeEnabled.value = enabled
    }

    fun setHideOnlineStatus(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("hide_online_status", enabled).apply()
        _hideOnlineStatus.value = enabled
    }

    fun setHideTypingIndicator(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("hide_typing_indicator", enabled).apply()
        _hideTypingIndicator.value = enabled
    }

    fun setHideReadReceipts(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("hide_read_receipts", enabled).apply()
        _hideReadReceipts.value = enabled
    }

    // Utility
    fun resetAllSettings() {
        sharedPreferences.edit().clear().apply()
        _ghostModeEnabled.value = false
        _hideOnlineStatus.value = false
        _hideTypingIndicator.value = false
        _hideReadReceipts.value = false
    }

    fun getStatus(): GhostModeStatus {
        return GhostModeStatus(
            ghostModeEnabled = ghostModeEnabled.value,
            hideOnlineStatus = hideOnlineStatus.value,
            hideTypingIndicator = hideTypingIndicator.value,
            hideReadReceipts = hideReadReceipts.value
        )
    }
}

data class GhostModeStatus(
    val ghostModeEnabled: Boolean,
    val hideOnlineStatus: Boolean,
    val hideTypingIndicator: Boolean,
    val hideReadReceipts: Boolean
)
