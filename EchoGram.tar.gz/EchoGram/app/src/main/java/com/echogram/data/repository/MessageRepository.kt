package com.echogram.data.repository

import com.echogram.data.database.MessageDao
import com.echogram.data.database.MessageEditDao
import com.echogram.data.database.MessageEntity
import com.echogram.data.database.MessageEditEntity
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest

class MessageRepository(
    private val messageDao: MessageDao,
    private val messageEditDao: MessageEditDao
) {
    // Get all messages
    fun getAllMessages(): Flow<List<MessageEntity>> {
        return messageDao.getAllMessages()
    }

    // Get messages for specific chat
    fun getMessagesByChat(chatId: String): Flow<List<MessageEntity>> {
        return messageDao.getMessagesByChat(chatId)
    }

    // Get deleted messages
    fun getDeletedMessages(): Flow<List<MessageEntity>> {
        return messageDao.getDeletedMessages()
    }

    // Get edited messages
    fun getEditedMessages(): Flow<List<MessageEntity>> {
        return messageDao.getEditedMessages()
    }

    // Search messages
    fun searchMessages(query: String): Flow<List<MessageEntity>> {
        return messageDao.searchMessages(query)
    }

    // Get edit history for a message
    fun getEditHistory(messageId: Int): Flow<List<MessageEditEntity>> {
        return messageEditDao.getEditHistory(messageId)
    }

    // Save new message
    suspend fun saveMessage(
        sender: String,
        content: String,
        chatId: String
    ) {
        val message = MessageEntity(
            sender = sender,
            content = content,
            timestamp = System.currentTimeMillis(),
            chatId = chatId,
            messageHash = generateHash(content),
            isDeleted = false,
            isEdited = false
        )
        messageDao.insertMessage(message)
    }

    // Mark message as deleted
    suspend fun markMessageAsDeleted(messageId: Int) {
        val message = messageDao.getMessageById(messageId) ?: return
        messageDao.updateMessage(message.copy(isDeleted = true))
    }

    // Record message edit
    suspend fun recordMessageEdit(
        messageId: Int,
        previousContent: String,
        newContent: String
    ) {
        val message = messageDao.getMessageById(messageId) ?: return
        val editCount = messageEditDao.getEditCount(messageId)

        val edit = MessageEditEntity(
            messageId = messageId,
            previousContent = previousContent,
            editedContent = newContent,
            editTimestamp = System.currentTimeMillis(),
            editNumber = editCount + 1
        )

        messageEditDao.insertEdit(edit)
        messageDao.updateMessage(message.copy(isEdited = true))
    }

    // Delete message from database
    suspend fun deleteMessage(messageId: Int) {
        messageDao.deleteMessageById(messageId)
        messageEditDao.deleteEditsForMessage(messageId)
    }

    // Get message statistics
    suspend fun getMessageStats(): MessageStats {
        return MessageStats(
            totalMessages = messageDao.getMessageCount(),
            deletedMessages = messageDao.getDeletedMessageCount(),
            editedMessages = messageDao.getEditedMessageCount()
        )
    }

    // Clear all messages
    suspend fun clearAllMessages() {
        messageDao.deleteAllMessages()
    }

    // Utility: Generate hash for message content
    private fun generateHash(content: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(content.toByteArray())
        return hash.joinToString("") { "%02x".format(it) }
    }
}

data class MessageStats(
    val totalMessages: Int,
    val deletedMessages: Int,
    val editedMessages: Int
)
