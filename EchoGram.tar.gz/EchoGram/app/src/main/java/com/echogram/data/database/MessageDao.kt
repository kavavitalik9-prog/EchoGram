package com.echogram.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp DESC")
    fun getMessagesByChat(chatId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE id = :messageId")
    suspend fun getMessageById(messageId: Int): MessageEntity?

    @Query("SELECT * FROM messages WHERE isDeleted = 1 ORDER BY timestamp DESC")
    fun getDeletedMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE isEdited = 1 ORDER BY timestamp DESC")
    fun getEditedMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE content LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchMessages(query: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Update
    suspend fun updateMessage(message: MessageEntity)

    @Delete
    suspend fun deleteMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :messageId")
    suspend fun deleteMessageById(messageId: Int)

    @Query("DELETE FROM messages")
    suspend fun deleteAllMessages()

    @Query("SELECT COUNT(*) FROM messages")
    suspend fun getMessageCount(): Int

    @Query("SELECT COUNT(*) FROM messages WHERE isDeleted = 1")
    suspend fun getDeletedMessageCount(): Int

    @Query("SELECT COUNT(*) FROM messages WHERE isEdited = 1")
    suspend fun getEditedMessageCount(): Int
}

@Dao
interface MessageEditDao {
    @Query("SELECT * FROM message_edits WHERE messageId = :messageId ORDER BY editNumber ASC")
    fun getEditHistory(messageId: Int): Flow<List<MessageEditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEdit(edit: MessageEditEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEdits(edits: List<MessageEditEntity>)

    @Delete
    suspend fun deleteEdit(edit: MessageEditEntity)

    @Query("DELETE FROM message_edits WHERE messageId = :messageId")
    suspend fun deleteEditsForMessage(messageId: Int)

    @Query("SELECT COUNT(*) FROM message_edits WHERE messageId = :messageId")
    suspend fun getEditCount(messageId: Int): Int
}
