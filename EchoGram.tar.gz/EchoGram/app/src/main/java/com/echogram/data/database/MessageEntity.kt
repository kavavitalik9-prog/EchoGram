package com.echogram.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val sender: String,
    val content: String,
    val timestamp: Long,
    val isDeleted: Boolean = false,
    val isEdited: Boolean = false,
    val chatId: String,
    val messageHash: String // Hash for deduplication
)

@Entity(
    tableName = "message_edits",
    foreignKeys = [
        ForeignKey(
            entity = MessageEntity::class,
            parentColumns = ["id"],
            childColumns = ["messageId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class MessageEditEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val messageId: Int,
    val previousContent: String,
    val editedContent: String,
    val editTimestamp: Long,
    val editNumber: Int // 1st edit, 2nd edit, etc.
)
