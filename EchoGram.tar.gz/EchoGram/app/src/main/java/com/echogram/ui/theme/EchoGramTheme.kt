package com.echogram.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Cyberpunk Minimalism Color Palette
private val CyanNeon = Color(0xFF00D9FF)
private val MagentaNeon = Color(0xFFFF006E)
private val DarkNavy = Color(0xFF0A1628)
private val DarkCharcoal = Color(0xFF1A1A1A)
private val PureWhite = Color(0xFFFFFFFF)
private val LightGray = Color(0xFFE0E0E0)

private val DarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    secondary = MagentaNeon,
    tertiary = Color(0xFF8B5CF6),
    background = DarkNavy,
    surface = DarkCharcoal,
    onBackground = PureWhite,
    onSurface = PureWhite,
    surfaceVariant = Color(0xFF2A2A2A),
    onSurfaceVariant = LightGray,
    outline = CyanNeon,
    outlineVariant = MagentaNeon
)

private val LightColorScheme = lightColorScheme(
    primary = CyanNeon,
    secondary = MagentaNeon,
    tertiary = Color(0xFF8B5CF6),
    background = PureWhite,
    surface = LightGray,
    onBackground = DarkNavy,
    onSurface = DarkNavy,
    surfaceVariant = Color(0xFFF5F5F5),
    onSurfaceVariant = Color(0xFF666666),
    outline = CyanNeon,
    outlineVariant = MagentaNeon
)

@Composable
fun EchoGramTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = EchoGramTypography,
        content = content
    )
}

// Typography for Cyberpunk Minimalism
val EchoGramTypography = Typography(
    displayLarge = Typography().displayLarge.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 32.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp
    ),
    displayMedium = Typography().displayMedium.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 28.sp,
        fontWeight = FontWeight.Bold
    ),
    displaySmall = Typography().displaySmall.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold
    ),
    headlineLarge = Typography().headlineLarge.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold
    ),
    headlineMedium = Typography().headlineMedium.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 20.sp,
        fontWeight = FontWeight.SemiBold
    ),
    headlineSmall = Typography().headlineSmall.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold
    ),
    bodyLarge = Typography().bodyLarge.copy(
        fontSize = 16.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 24.sp
    ),
    bodyMedium = Typography().bodyMedium.copy(
        fontSize = 14.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 20.sp
    ),
    bodySmall = Typography().bodySmall.copy(
        fontSize = 12.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 16.sp
    ),
    labelLarge = Typography().labelLarge.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp
    ),
    labelMedium = Typography().labelMedium.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp
    ),
    labelSmall = Typography().labelSmall.copy(
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp
    )
)
