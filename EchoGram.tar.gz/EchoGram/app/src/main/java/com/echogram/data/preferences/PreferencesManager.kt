package com.echogram.data.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class PreferencesManager(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "echogram_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // Theme
    private val _darkModeEnabled = MutableStateFlow(getDarkModeEnabled())
    val darkModeEnabled: StateFlow<Boolean> = _darkModeEnabled

    // Notifications
    private val _notificationsEnabled = MutableStateFlow(getNotificationsEnabled())
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled

    // Backup
    private val _autoBackupEnabled = MutableStateFlow(getAutoBackupEnabled())
    val autoBackupEnabled: StateFlow<Boolean> = _autoBackupEnabled

    // App Lock
    private val _appLockEnabled = MutableStateFlow(getAppLockEnabled())
    val appLockEnabled: StateFlow<Boolean> = _appLockEnabled

    // Getters
    private fun getDarkModeEnabled(): Boolean {
        return sharedPreferences.getBoolean("dark_mode", true)
    }

    private fun getNotificationsEnabled(): Boolean {
        return sharedPreferences.getBoolean("notifications_enabled", true)
    }

    private fun getAutoBackupEnabled(): Boolean {
        return sharedPreferences.getBoolean("auto_backup", false)
    }

    private fun getAppLockEnabled(): Boolean {
        return sharedPreferences.getBoolean("app_lock_enabled", false)
    }

    fun getAppLockPin(): String? {
        return sharedPreferences.getString("app_lock_pin", null)
    }

    fun getLastBackupTime(): Long {
        return sharedPreferences.getLong("last_backup_time", 0L)
    }

    // Setters
    fun setDarkModeEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("dark_mode", enabled).apply()
        _darkModeEnabled.value = enabled
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("notifications_enabled", enabled).apply()
        _notificationsEnabled.value = enabled
    }

    fun setAutoBackupEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("auto_backup", enabled).apply()
        _autoBackupEnabled.value = enabled
    }

    fun setAppLockEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("app_lock_enabled", enabled).apply()
        _appLockEnabled.value = enabled
    }

    fun setAppLockPin(pin: String) {
        sharedPreferences.edit().putString("app_lock_pin", pin).apply()
    }

    fun setLastBackupTime(timestamp: Long) {
        sharedPreferences.edit().putLong("last_backup_time", timestamp).apply()
    }

    // Utility
    fun resetAllSettings() {
        sharedPreferences.edit().clear().apply()
        _darkModeEnabled.value = true
        _notificationsEnabled.value = true
        _autoBackupEnabled.value = false
        _appLockEnabled.value = false
    }

    fun getAppSettings(): AppSettings {
        return AppSettings(
            darkModeEnabled = darkModeEnabled.value,
            notificationsEnabled = notificationsEnabled.value,
            autoBackupEnabled = autoBackupEnabled.value,
            appLockEnabled = appLockEnabled.value
        )
    }
}

data class AppSettings(
    val darkModeEnabled: Boolean,
    val notificationsEnabled: Boolean,
    val autoBackupEnabled: Boolean,
    val appLockEnabled: Boolean
)
