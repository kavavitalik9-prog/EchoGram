# 🚀 Как получить готовый APK файл EchoGram

Есть несколько способов собрать APK приложения без установки Android Studio на компьютер.

## ✅ Способ 1: Через GitHub Actions (САМЫЙ ПРОСТОЙ)

### Шаг 1: Создайте GitHub аккаунт
- Перейдите на https://github.com
- Нажмите "Sign up" и создайте бесплатный аккаунт

### Шаг 2: Загрузите проект на GitHub
1. На GitHub нажмите **"+"** → **"New repository"**
2. Назовите его **"EchoGram"**
3. Нажмите **"Create repository"**
4. Следуйте инструкциям для загрузки файлов:
   ```bash
   git clone https://github.com/ВАШ_ЮЗЕР/EchoGram.git
   cd EchoGram
   # Скопируйте все файлы проекта сюда
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

### Шаг 3: Создайте GitHub Actions workflow
1. На странице репозитория нажмите **"Actions"**
2. Нажмите **"set up a workflow yourself"**
3. Скопируйте этот код в файл `.github/workflows/build.yml`:

```yaml
name: Build APK

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v3
    
    - name: Set up JDK 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
        cache: gradle

    - name: Grant execute permission for gradlew
      run: chmod +x gradlew

    - name: Build with Gradle
      run: ./gradlew assembleDebug

    - name: Upload APK
      uses: actions/upload-artifact@v3
      with:
        name: app-debug
        path: app/build/outputs/apk/debug/app-debug.apk
```

4. Нажмите **"Start commit"** → **"Commit new file"**

### Шаг 4: Скачайте готовый APK
1. Перейдите в **"Actions"**
2. Дождитесь завершения сборки (зеленая галочка ✅)
3. Нажмите на завершенную сборку
4. Внизу нажмите **"app-debug"** → скачайте файл
5. Это ваш готовый **app-debug.apk** файл!

---

## ✅ Способ 2: Через Appetize.io (БЕЗ GITHUB)

### Шаг 1: Загрузите проект
1. Перейдите на https://appetize.io
2. Нажмите **"Upload"**
3. Загрузите архив EchoGram.tar.gz

### Шаг 2: Дождитесь сборки
- Сервис автоматически соберет APK
- Вы получите ссылку для скачивания

---

## ✅ Способ 3: Через App Center (Microsoft)

### Шаг 1: Создайте аккаунт
- Перейдите на https://appcenter.ms
- Зарегистрируйтесь

### Шаг 2: Создайте новое приложение
1. Нажмите **"Add new app"**
2. Выберите **"Android"** и **"Build"**
3. Подключите GitHub репозиторий

### Шаг 3: Настройте сборку
1. Выберите ветку **"main"**
2. Нажмите **"Configure build"**
3. Выберите **"Debug"** вариант сборки
4. Нажмите **"Save & Build"**

### Шаг 4: Скачайте APK
- После завершения сборки нажмите **"Download"**

---

## 📱 Как установить APK на телефон

### Способ 1: Через USB кабель
1. Подключите Android телефон USB кабелем к компьютеру
2. Включите "Отладку по USB" на телефоне (Settings → Developer Options)
3. Дважды нажмите на файл **app-debug.apk**
4. Нажмите **"Установить"**

### Способ 2: Через QR код
1. Загрузите APK на облако (Google Drive, Dropbox и т.д.)
2. Получите ссылку для скачивания
3. Создайте QR код из ссылки на https://qr-code-generator.com
4. Отсканируйте QR кодом на телефоне
5. Нажмите ссылку и установите приложение

### Способ 3: Через Telegram/Email
1. Отправьте себе APK файл в Telegram или на Email
2. Откройте на телефоне
3. Нажмите **"Установить"**

---

## ⚠️ Важные замечания

- **Debug APK**: Файл app-debug.apk предназначен для тестирования
- **Размер**: Примерно 50-100 MB
- **Требования**: Android 8.0+ (API 26+)
- **Подпись**: Debug APK подписан автоматически

---

## 🆘 Если что-то не работает

1. **Сборка не запускается**: Проверьте, что все файлы проекта загружены
2. **Ошибка при установке**: Удалите старую версию приложения
3. **Приложение крашится**: Проверьте логи в Android Studio

---

**Выбирайте способ 1 (GitHub Actions) - это самый простой и быстрый способ!** ⭐
