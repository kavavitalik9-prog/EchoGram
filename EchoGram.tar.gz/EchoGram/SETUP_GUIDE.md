# EchoGram Setup Guide

## Prerequisites

Before setting up EchoGram, ensure you have the following installed on your system:

### Required Software
- **Android Studio**: Version Arctic Fox (2020.3.1) or later
  - Download from: https://developer.android.com/studio
- **Java Development Kit (JDK)**: Version 17 or later
  - Recommended: OpenJDK 17 or Oracle JDK 17
- **Android SDK**: API Level 34 (Android 14)
  - Installed automatically with Android Studio
- **Gradle**: Version 8.1.0 or later
  - Bundled with Android Studio

### System Requirements
- **OS**: Windows, macOS, or Linux
- **RAM**: Minimum 8GB (16GB recommended)
- **Disk Space**: At least 10GB free space
- **Internet**: Required for downloading dependencies

## Installation Steps

### 1. Clone the Repository

```bash
# Using HTTPS
git clone https://github.com/yourusername/EchoGram.git
cd EchoGram

# Or using SSH
git clone git@github.com:yourusername/EchoGram.git
cd EchoGram
```

### 2. Open in Android Studio

1. Launch Android Studio
2. Click **File** → **Open**
3. Navigate to the EchoGram directory
4. Click **Open**
5. Wait for Gradle sync to complete (this may take 2-5 minutes)

### 3. Configure SDK

If Android Studio prompts you to install missing components:

1. Accept the installation of required SDK components
2. Wait for the installation to complete
3. Restart Android Studio if prompted

### 4. Build the Project

```bash
# Using Gradle wrapper (recommended)
./gradlew build

# Or using Android Studio
Build → Make Project (Ctrl+F9 on Windows/Linux, Cmd+F9 on macOS)
```

### 5. Run on Emulator

#### Option A: Using Android Studio

1. Click **Run** → **Run 'app'** (Shift+F10)
2. Select or create an Android Virtual Device (AVD)
3. Click **OK** to launch the emulator and app

#### Option B: Using Command Line

```bash
# Install on connected device or emulator
./gradlew installDebug

# Launch the app
adb shell am start -n com.echogram/.MainActivity
```

### 6. Run on Physical Device

1. **Enable Developer Mode** on your Android device:
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times
   - Go back to Settings → Developer Options
   - Enable "USB Debugging"

2. **Connect device via USB**

3. **Run the app**:
   - Click **Run** → **Run 'app'**
   - Select your physical device
   - Click **OK**

## Project Structure Overview

```
EchoGram/
├── app/                          # Main application module
│   ├── src/main/
│   │   ├── java/com/echogram/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/
│   │   │   │   ├── database/     # Room database entities & DAOs
│   │   │   │   ├── preferences/  # SharedPreferences managers
│   │   │   │   └── repository/   # Data repositories
│   │   │   └── ui/
│   │   │       ├── screens/      # Composable screens
│   │   │       └── theme/        # Theme configuration
│   │   ├── AndroidManifest.xml
│   │   └── res/                  # Resources (strings, colors, etc.)
│   ├── build.gradle.kts          # App-level build configuration
│   └── proguard-rules.pro        # ProGuard obfuscation rules
├── build.gradle.kts              # Project-level build configuration
├── settings.gradle.kts           # Gradle settings
├── gradle.properties             # Gradle properties
├── README.md                     # Project overview
├── ARCHITECTURE.md               # Architecture documentation
└── SETUP_GUIDE.md               # This file
```

## Gradle Configuration

### Key Dependencies

The project uses the following major dependencies:

- **Jetpack Compose**: UI framework
- **Material3**: Material Design components
- **Room**: Local database
- **Navigation Compose**: Screen navigation
- **Coroutines**: Asynchronous programming
- **Hilt**: Dependency injection (future implementation)

### Build Variants

```bash
# Debug build (for development)
./gradlew assembleDebug

# Release build (optimized)
./gradlew assembleRelease

# Run tests
./gradlew test
```

## Troubleshooting

### Issue: Gradle Sync Failed

**Solution**:
1. Click **File** → **Invalidate Caches** → **Invalidate and Restart**
2. Wait for Android Studio to restart
3. Gradle should sync automatically

### Issue: SDK Components Missing

**Solution**:
1. Go to **Tools** → **SDK Manager**
2. Ensure API Level 34 is installed
3. Install any missing components
4. Click **Apply** and **OK**

### Issue: Emulator Won't Start

**Solution**:
1. Go to **Tools** → **Device Manager**
2. Create a new Android Virtual Device (AVD)
3. Select API Level 34 and a system image
4. Click **Finish** and wait for creation
5. Click the play button to start the emulator

### Issue: App Crashes on Launch

**Solution**:
1. Check the Logcat window (View → Tool Windows → Logcat)
2. Look for error messages
3. Common causes:
   - Missing permissions in AndroidManifest.xml
   - Database initialization issues
   - Missing dependencies

### Issue: Build Takes Too Long

**Solution**:
1. Increase Gradle heap size in `gradle.properties`:
   ```properties
   org.gradle.jvmargs=-Xmx4096m
   ```
2. Enable parallel builds:
   ```properties
   org.gradle.parallel=true
   ```
3. Enable build cache:
   ```properties
   org.gradle.caching=true
   ```

## Development Workflow

### Making Changes

1. **Edit code** in Android Studio
2. **Save files** (Ctrl+S / Cmd+S)
3. **Rebuild** (Ctrl+F9 / Cmd+F9)
4. **Hot Reload** (Ctrl+F5 / Cmd+F5) - For Compose changes

### Running Tests

```bash
# Unit tests
./gradlew test

# Instrumented tests (on emulator/device)
./gradlew connectedAndroidTest

# Specific test class
./gradlew test --tests com.echogram.ExampleTest
```

### Debugging

1. **Set Breakpoints**: Click on line number in code editor
2. **Debug App**: Click **Run** → **Debug 'app'**
3. **Step Through Code**: Use F10 (step over) or F11 (step into)
4. **Inspect Variables**: Hover over variables or use Variables panel

## Building for Release

### Generate Signed APK

1. Click **Build** → **Generate Signed Bundle / APK**
2. Select **APK**
3. Click **Next**
4. Create or select a keystore file
5. Enter keystore password
6. Select build variant: **release**
7. Click **Finish**
8. APK will be generated in `app/release/`

### Generate App Bundle (for Play Store)

1. Click **Build** → **Generate Signed Bundle / APK**
2. Select **Android App Bundle**
3. Follow the same steps as APK generation
4. Bundle will be generated in `app/release/`

## Next Steps

1. **Explore the codebase**: Read through the main screens and understand the UI structure
2. **Review ARCHITECTURE.md**: Understand the project architecture
3. **Implement features**: Start adding real functionality
4. **Write tests**: Add unit and UI tests
5. **Optimize performance**: Profile and optimize the app

## Additional Resources

- **Android Documentation**: https://developer.android.com/docs
- **Jetpack Compose**: https://developer.android.com/jetpack/compose
- **Material Design 3**: https://m3.material.io/
- **Kotlin Documentation**: https://kotlinlang.org/docs/
- **Room Database**: https://developer.android.com/training/data-storage/room

## Support

For issues or questions:
1. Check the **Troubleshooting** section above
2. Review the **ARCHITECTURE.md** file
3. Check Android Studio's Logcat for error messages
4. Search Stack Overflow for similar issues
5. Open an issue on the GitHub repository

---

**Happy coding! 🚀**
