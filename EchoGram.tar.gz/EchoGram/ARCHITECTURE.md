# EchoGram Architecture Documentation

## Overview

EchoGram is built using modern Android development practices with a focus on clean architecture, maintainability, and user experience. This document outlines the technical architecture and design patterns used throughout the application.

## Architecture Pattern: MVVM + Jetpack Compose

The application follows the **Model-View-ViewModel (MVVM)** pattern combined with **Jetpack Compose** for declarative UI development.

```
┌─────────────────────────────────────────────────────┐
│                    UI Layer                         │
│  (Jetpack Compose - HomeScreen, MessagesScreen)    │
└────────────────────┬────────────────────────────────┘
                     │
                     ↓
┌─────────────────────────────────────────────────────┐
│              ViewModel Layer                        │
│  (State Management, Business Logic)                │
└────────────────────┬────────────────────────────────┘
                     │
                     ↓
┌─────────────────────────────────────────────────────┐
│           Repository Layer                         │
│  (Data Access, Caching, API Calls)                │
└────────────────────┬────────────────────────────────┘
                     │
                     ↓
┌─────────────────────────────────────────────────────┐
│            Data Layer                              │
│  (Room Database, SharedPreferences, APIs)         │
└─────────────────────────────────────────────────────┘
```

## Layer Breakdown

### 1. UI Layer (Presentation)

**Location**: `app/src/main/java/com/echogram/ui/`

The UI layer is built entirely with **Jetpack Compose**, a modern declarative UI framework. It consists of:

#### Screens
- **HomeScreen**: Main dashboard with feature cards
- **MessagesScreen**: Message recovery and viewing deleted messages
- **GhostModeScreen**: Privacy controls and phantom mode settings
- **SettingsScreen**: Application preferences and customization

#### Theme System
- **EchoGramTheme.kt**: Centralized theme definition with Cyberpunk Minimalism colors
- **Typography**: Monospace fonts for technical aesthetic
- **Color Palette**: Cyan, Magenta, Navy, and Charcoal colors

#### Key Characteristics
- **Composable Functions**: Reusable UI components
- **State Management**: Using `remember` and `mutableStateOf` for local state
- **Navigation**: Jetpack Navigation Compose for screen transitions
- **Responsive Design**: Adapts to different screen sizes

### 2. ViewModel Layer

**Future Implementation**: `app/src/main/java/com/echogram/viewmodel/`

ViewModels will manage:
- Screen-specific state
- Business logic coordination
- Lifecycle-aware data handling
- Communication with repositories

**Example Structure**:
```kotlin
class MessagesViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()
    
    fun loadMessages() { /* ... */ }
    fun deleteMessage(id: Int) { /* ... */ }
}
```

### 3. Repository Layer

**Future Implementation**: `app/src/main/java/com/echogram/data/repository/`

Repositories serve as the single source of truth for data:
- Abstract data sources (local database, API, cache)
- Implement business logic for data operations
- Handle error management and retries

**Example Structure**:
```kotlin
class MessageRepository(
    private val messageDao: MessageDao,
    private val apiService: TelegramApiService
) {
    fun getMessages(): Flow<List<Message>> = messageDao.getAllMessages()
    suspend fun syncMessages() { /* ... */ }
}
```

### 4. Data Layer

**Future Implementation**: `app/src/main/java/com/echogram/data/`

#### Database (Room)
```kotlin
@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: Int,
    val sender: String,
    val content: String,
    val timestamp: Long,
    val isDeleted: Boolean,
    val editHistory: String // JSON serialized
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessages(): Flow<List<MessageEntity>>
    
    @Insert
    suspend fun insertMessage(message: MessageEntity)
}
```

#### Local Storage
- **SharedPreferences**: User preferences, theme settings
- **Encrypted SharedPreferences**: Sensitive data like app lock PIN
- **Room Database**: Persistent message storage

#### API Integration
- **Retrofit**: HTTP client for API calls
- **OkHttp**: Network interceptors for logging and error handling
- **Serialization**: Kotlinx Serialization for JSON parsing

## Navigation Flow

```
MainActivity
    ↓
EchoGramApp (NavHost)
    ├── Home Screen
    │   ├── → Messages Screen
    │   ├── → Ghost Mode Screen
    │   └── → Settings Screen
    ├── Messages Screen
    │   └── → (Back to Home)
    ├── Ghost Mode Screen
    │   └── → (Back to Home)
    └── Settings Screen
        └── → (Back to Home)
```

## State Management Strategy

### Local State (Composable Level)
```kotlin
var isExpanded by remember { mutableStateOf(false) }
var selectedTheme by remember { mutableStateOf("dark") }
```

### Screen State (ViewModel Level - Future)
```kotlin
val uiState: StateFlow<MessagesUiState> = _uiState.asStateFlow()
```

### Global State (Application Level - Future)
```kotlin
// Using Hilt for dependency injection
@Singleton
class AppState {
    val isDarkMode: MutableState<Boolean> = mutableStateOf(true)
}
```

## Dependency Injection with Hilt

**Future Implementation**: Hilt will manage all dependencies

```kotlin
@HiltAndroidApp
class EchoGramApplication : Application()

class MainActivity : ComponentActivity() {
    @Inject
    lateinit var messageRepository: MessageRepository
}
```

## Data Flow Example: Message Recovery

```
User opens MessagesScreen
    ↓
MessagesViewModel.loadMessages()
    ↓
MessageRepository.getMessages()
    ↓
MessageDao.getAllMessages() [Room Database]
    ↓
Flow<List<Message>>
    ↓
UI renders with deleted messages marked
    ↓
User taps message
    ↓
Composable state updates
    ↓
Edit history displayed
```

## Threading & Coroutines

- **Main Thread**: UI updates only
- **IO Thread**: Database and network operations
- **Default Thread**: Heavy computations

```kotlin
viewModelScope.launch(Dispatchers.IO) {
    val messages = messageRepository.getMessages()
    withContext(Dispatchers.Main) {
        _uiState.value = UiState.Success(messages)
    }
}
```

## Error Handling

```kotlin
sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val exception: Exception) : Result<Nothing>()
    object Loading : Result<Nothing>()
}
```

## Testing Strategy

### Unit Tests
- ViewModel logic
- Repository data transformations
- Utility functions

### UI Tests
- Compose component rendering
- Navigation flows
- User interactions

### Integration Tests
- Database operations
- API calls
- End-to-end flows

## Performance Considerations

1. **Lazy Loading**: Messages loaded in chunks
2. **Caching**: In-memory cache for frequently accessed data
3. **Database Indexing**: Optimized queries on message tables
4. **Compose Optimization**: Proper use of `remember` and `key` functions

## Security Architecture

1. **Encryption**: Sensitive data encrypted at rest
2. **Secure Storage**: Using EncryptedSharedPreferences
3. **Network Security**: Certificate pinning for API calls
4. **Permissions**: Minimal permissions requested
5. **Code Obfuscation**: ProGuard rules applied in release builds

## Future Enhancements

1. **Real Telegram Integration**: TDLib integration for actual Telegram connectivity
2. **Cloud Sync**: Optional encrypted cloud backup
3. **Offline Support**: Offline-first architecture with sync
4. **Advanced Analytics**: User behavior tracking (privacy-respecting)
5. **Plugin System**: Allow third-party extensions

---

This architecture provides a solid foundation for scaling EchoGram while maintaining code quality, testability, and user experience.
